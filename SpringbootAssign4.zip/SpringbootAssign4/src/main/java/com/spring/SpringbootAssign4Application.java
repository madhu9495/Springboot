package com.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootAssign4Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootAssign4Application.class, args);
	}
}
