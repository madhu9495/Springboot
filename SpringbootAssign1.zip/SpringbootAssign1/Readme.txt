to run springboot app run Application.java

to access the app url should be http://localhost:9090/bank/

to access bank name url should be http://localhost:9090/bank/name

to access bank address url should be http://localhost:9090/bank/name