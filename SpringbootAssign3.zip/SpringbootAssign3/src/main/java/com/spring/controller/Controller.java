package com.spring.controller;



import org.springframework.web.bind.annotation.RequestMapping;

@org.springframework.stereotype.Controller
@RequestMapping("/bank")
public class Controller {
	
	@RequestMapping("/bankdetails")
	public String getBankdetails() {
	 
	  return "bankdetails";
	  }
	
	@RequestMapping("/services")
	public String getServices() {
		
	    return "bankservices";

	}
}
